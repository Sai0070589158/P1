you can run like this ..

1 - make a virtual env first

2 - install all requirements 

3 - run the below command 


uvicorn app.main:app --reload


